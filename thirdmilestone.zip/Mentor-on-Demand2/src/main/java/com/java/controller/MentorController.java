package com.java.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.model.Mentor;
import com.java.model.MentorSkills;

import com.java.repo.MentorRepository;
import com.java.repo.MentorSkillsRepository;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class MentorController  {
	@Autowired
	private MentorRepository repository;
	@Autowired
	private MentorSkillsRepository mentorSkillsrepository;

	
	@GetMapping("/mentor/getDetails/{mid}")
	public Optional<Mentor> getAllDetails(@PathVariable("mid") long mid) {
		System.out.println("Get all Trainings of id...");
		Optional<Mentor> mentorSkills = repository.findById(mid);
		return mentorSkills;
	}
	

	@GetMapping("/mentor/getSearch/{skill_name}")
	public List<MentorSkills> getAllSearchDetails(@PathVariable("skill_name") String skill_name){
		System.out.println("Get all Trainings of id...");
		List<MentorSkills> mentorDetails = mentorSkillsrepository.getBySkillName(skill_name);
		return mentorDetails;
	}

}
