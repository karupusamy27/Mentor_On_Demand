import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { SigninComponent } from './component/signin/signin.component';
import { UssignComponent } from './component/ussign/ussign.component';
import { MensignComponent } from './component/mensign/mensign.component';
import { UssearchComponent } from './component/ussearch/ussearch.component';
import { UsfirstComponent } from './component/usfirst/usfirst.component';
import { UsnavComponent } from './component/usnav/usnav.component';
import { UsfindComponent } from './component/usfind/usfind.component';
import { UscourseComponent } from './component/uscourse/uscourse.component';
import { UsproComponent } from './component/uspro/uspro.component';
import { MennavComponent } from './component/mennav/mennav.component';
import { MenfirstComponent } from './component/menfirst/menfirst.component';
import { MennotComponent } from './component/mennot/mennot.component';
import { MenpayComponent } from './component/menpay/menpay.component';
import { AdnavComponent } from './component/adnav/adnav.component';
import { AdfirstComponent } from './component/adfirst/adfirst.component';
import { AdpayComponent } from './component/adpay/adpay.component';
import { AdtechComponent } from './component/adtech/adtech.component';
import { AdpaymodeComponent } from './component/adpaymode/adpaymode.component';
import { AdactionComponent } from './component/adaction/adaction.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SigninComponent,
    UssignComponent,
    MensignComponent,
    UssearchComponent,
    UsfirstComponent,
    UsnavComponent,
    UsfindComponent,
    UscourseComponent,
    UsproComponent,
    MennavComponent,
    MenfirstComponent,
    MennotComponent,
    MenpayComponent,
    AdnavComponent,
    AdfirstComponent,
    AdpayComponent,
    AdtechComponent,
    AdpaymodeComponent,
    AdactionComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
