import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { SigninComponent } from './component/signin/signin.component';
import { UssignComponent } from './component/ussign/ussign.component';
import { MensignComponent } from './component/mensign/mensign.component';
import { UssearchComponent } from './component/ussearch/ussearch.component';
import { UsfirstComponent } from './component/usfirst/usfirst.component';
import { UsnavComponent } from './component/usnav/usnav.component';
import { UsfindComponent } from './component/usfind/usfind.component';
import { UscourseComponent } from './component/uscourse/uscourse.component';
import { MenfirstComponent } from './component/menfirst/menfirst.component';
import { MennavComponent } from './component/mennav/mennav.component';
import { MenpayComponent } from './component/menpay/menpay.component';
import { MennotComponent } from './component/mennot/mennot.component';
import { AdnavComponent } from './component/adnav/adnav.component';
import { AdfirstComponent } from './component/adfirst/adfirst.component';
import { AdpayComponent } from './component/adpay/adpay.component';
import { AdtechComponent } from './component/adtech/adtech.component';
import { UsproComponent } from './component/uspro/uspro.component';
import { AdactionComponent } from './component/adaction/adaction.component';
import { AdpaymodeComponent } from './component/adpaymode/adpaymode.component';


const routes: Routes = [
  {
    path:'',redirectTo:'home',pathMatch:'full'
  },
  {
    path:'home',component:HomeComponent,
    children:[
      {
        path:'',redirectTo:'ussearch',pathMatch:'full'
      },
      {
        path:'ussearch',component:UssearchComponent,
      },
    ]
  },
  {
    path:'signin',component:SigninComponent,
  },
  {
    path:'ussign',component:UssignComponent,
  },
  {
    path:'mensign',component:MensignComponent,
  },
  {
    path:'usnav',component:UsnavComponent,
  },
  {
    path:'usfirst',component:UsfirstComponent,
  },
  {
    path:'usnav',component:UsnavComponent,
  },
  {
    path:'usfind',component:UsfindComponent,
  },
  {
    path:'uscourse',component:UscourseComponent,
  },
  {
    path:'uspro',component:UsproComponent,
  },
  {
    path:'mennav',component:MennavComponent,
  },
  {
    path:'menfirst',component:MenfirstComponent,
  },
  {
    path:'mennot',component:MennotComponent,
  },
  {
    path:'adnav',component:AdnavComponent,
  },
  {
    path:'menpay',component:MenpayComponent,
  },
  {
    path:'adfirst',component:AdfirstComponent,
  },
  {
    path:'adpay',component:AdpayComponent,
  },
  {
    path:'adtech',component:AdtechComponent,
  },
  {
    path:'adpaymode',component:AdpaymodeComponent,
  },
  {
    path:'adaction',component:AdactionComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
