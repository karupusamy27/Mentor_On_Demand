import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menpay',
  templateUrl: './menpay.component.html',
  styleUrls: ['./menpay.component.css']
})
export class MenpayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
