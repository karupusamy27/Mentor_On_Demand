import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mennav',
  templateUrl: './mennav.component.html',
  styleUrls: ['./mennav.component.css']
})
export class MennavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
