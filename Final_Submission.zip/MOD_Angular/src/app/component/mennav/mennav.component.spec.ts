import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MennavComponent } from './mennav.component';

describe('MennavComponent', () => {
  let component: MennavComponent;
  let fixture: ComponentFixture<MennavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MennavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MennavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
