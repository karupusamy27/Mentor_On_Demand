import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UssearchComponent } from './ussearch.component';

describe('UssearchComponent', () => {
  let component: UssearchComponent;
  let fixture: ComponentFixture<UssearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UssearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UssearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
