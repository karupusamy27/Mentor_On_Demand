import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ussearch',
  templateUrl: './ussearch.component.html',
  styleUrls: ['./ussearch.component.css']
})
export class UssearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
