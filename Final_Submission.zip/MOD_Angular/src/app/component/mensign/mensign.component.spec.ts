import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MensignComponent } from './mensign.component';

describe('MensignComponent', () => {
  let component: MensignComponent;
  let fixture: ComponentFixture<MensignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MensignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MensignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
