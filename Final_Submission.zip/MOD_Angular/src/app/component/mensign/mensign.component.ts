import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mensign',
  templateUrl: './mensign.component.html',
  styleUrls: ['./mensign.component.css']
})
export class MensignComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
