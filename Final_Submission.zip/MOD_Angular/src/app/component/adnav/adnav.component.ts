import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adnav',
  templateUrl: './adnav.component.html',
  styleUrls: ['./adnav.component.css']
})
export class AdnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
