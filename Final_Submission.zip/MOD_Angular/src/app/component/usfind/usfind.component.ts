import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usfind',
  templateUrl: './usfind.component.html',
  styleUrls: ['./usfind.component.css']
})
export class UsfindComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
