import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsfindComponent } from './usfind.component';

describe('UsfindComponent', () => {
  let component: UsfindComponent;
  let fixture: ComponentFixture<UsfindComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsfindComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsfindComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
