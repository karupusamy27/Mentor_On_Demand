import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdactionComponent } from './adaction.component';

describe('AdactionComponent', () => {
  let component: AdactionComponent;
  let fixture: ComponentFixture<AdactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
