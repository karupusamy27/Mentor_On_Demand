import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adaction',
  templateUrl: './adaction.component.html',
  styleUrls: ['./adaction.component.css']
})
export class AdactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
