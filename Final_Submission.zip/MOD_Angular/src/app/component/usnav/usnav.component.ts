import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usnav',
  templateUrl: './usnav.component.html',
  styleUrls: ['./usnav.component.css']
})
export class UsnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
