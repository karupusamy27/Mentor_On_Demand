import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsnavComponent } from './usnav.component';

describe('UsnavComponent', () => {
  let component: UsnavComponent;
  let fixture: ComponentFixture<UsnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
