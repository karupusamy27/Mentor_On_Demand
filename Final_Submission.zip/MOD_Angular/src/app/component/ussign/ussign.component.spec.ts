import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UssignComponent } from './ussign.component';

describe('UssignComponent', () => {
  let component: UssignComponent;
  let fixture: ComponentFixture<UssignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UssignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UssignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
