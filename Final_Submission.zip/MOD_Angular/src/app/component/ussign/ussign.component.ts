import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ussign',
  templateUrl: './ussign.component.html',
  styleUrls: ['./ussign.component.css']
})
export class UssignComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
