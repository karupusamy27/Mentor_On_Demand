import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usfirst',
  templateUrl: './usfirst.component.html',
  styleUrls: ['./usfirst.component.css']
})
export class UsfirstComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
