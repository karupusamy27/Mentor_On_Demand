import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsfirstComponent } from './usfirst.component';

describe('UsfirstComponent', () => {
  let component: UsfirstComponent;
  let fixture: ComponentFixture<UsfirstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsfirstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsfirstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
