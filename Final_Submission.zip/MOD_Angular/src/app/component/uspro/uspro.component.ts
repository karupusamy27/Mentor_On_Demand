import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uspro',
  templateUrl: './uspro.component.html',
  styleUrls: ['./uspro.component.css']
})
export class UsproComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
