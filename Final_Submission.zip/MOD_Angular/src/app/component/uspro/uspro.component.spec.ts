import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsproComponent } from './uspro.component';

describe('UsproComponent', () => {
  let component: UsproComponent;
  let fixture: ComponentFixture<UsproComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsproComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsproComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
