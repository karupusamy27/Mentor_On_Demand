import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adpaymode',
  templateUrl: './adpaymode.component.html',
  styleUrls: ['./adpaymode.component.css']
})
export class AdpaymodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
