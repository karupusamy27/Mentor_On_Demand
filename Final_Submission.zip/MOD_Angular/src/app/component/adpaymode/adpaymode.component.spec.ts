import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdpaymodeComponent } from './adpaymode.component';

describe('AdpaymodeComponent', () => {
  let component: AdpaymodeComponent;
  let fixture: ComponentFixture<AdpaymodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdpaymodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdpaymodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
