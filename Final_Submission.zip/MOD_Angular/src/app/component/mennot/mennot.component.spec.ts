import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MennotComponent } from './mennot.component';

describe('MennotComponent', () => {
  let component: MennotComponent;
  let fixture: ComponentFixture<MennotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MennotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MennotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
