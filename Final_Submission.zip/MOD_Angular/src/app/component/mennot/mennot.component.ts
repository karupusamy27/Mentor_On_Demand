import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mennot',
  templateUrl: './mennot.component.html',
  styleUrls: ['./mennot.component.css']
})
export class MennotComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
