import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uscourse',
  templateUrl: './uscourse.component.html',
  styleUrls: ['./uscourse.component.css']
})
export class UscourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
