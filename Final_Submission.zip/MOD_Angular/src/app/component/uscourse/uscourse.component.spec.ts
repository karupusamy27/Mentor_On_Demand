import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UscourseComponent } from './uscourse.component';

describe('UscourseComponent', () => {
  let component: UscourseComponent;
  let fixture: ComponentFixture<UscourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UscourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UscourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
